This is the README for sct.
sct is a library on top of crpytography,python 
to provide easier access to most commonly used functionalities provided
by the package.