from setuptools import setup

setup(name='sct',
      version='0.1',
      description='sct package for crypto tools',
      url='https://github.com/ShankarCodes',
      author='shankar',
      author_email='mailstoshankar@gmail.com',
      license='MIT',
      packages=['sct'],
      zip_safe=True)